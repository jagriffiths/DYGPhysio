
document.addEventListener("DOMContentLoaded", () => {
  const includes = document.querySelectorAll("[include-html]");
  includes.forEach(async (el) => {
    const file = el.getAttribute("include-html");
    if (file) {
      const resp = await fetch(file);
      if (resp.ok) el.innerHTML = await resp.text();
      el.removeAttribute("include-html");
    }
  });
});
